import { useEffect, useState } from "react";

export default function useValidation(initialValue: string) {
  return {
    value: '',
    setValue: (newVal: string) => {},
    isValid: false,
  }
}
